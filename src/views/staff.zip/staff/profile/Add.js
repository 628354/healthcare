import React, { useState } from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
//import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
/* import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker'; */
//select field
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';


import Swal from 'sweetalert2';

const Add = ({setIsAdding }) => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [userName, setUserName] = useState('');
  const [password, setPassword] = useState('');
  const [cpassword, setCpassword] = useState('');
  
  const [role, setRole] = useState('');
  
  const [status, setStatus] = useState('');
  

  const handleAdd = e => {
    e.preventDefault();

    if (!firstName || !lastName || !email || !userName || !password ||!status || !cpassword) {
      return Swal.fire({
        icon: 'error',
        title: 'Error!',
        text: 'All fields are required.',
        showConfirmButton: true,
      });
    }
    if(password != cpassword){
      return Swal.fire({
        icon: 'error',
        title: 'Error!',
        text: 'Password And Confirm Password Does Not Match!.',
        showConfirmButton: true,
      });
    }

    //const id = employees.length + 1+1;
    const data = {
      stf_firstname:firstName,
      stf_lastname:lastName,
      stf_prfrdname:userName,
      stf_email:email,
      stf_pswrd:password,
      stf_status:status,
    };
    console.log(data);

    /* employees.push(newEmployee);
    localStorage.setItem('employees_data', JSON.stringify(employees));
    setEmployees(employees); 
    setIsAdding(false); */
    //let url = process.env.REACT_APP_BASE_URL;
    
    let url="https://tactytechnology.com/mycarepoint/api/";
    let endpoint = 'insertData?table=fms_staff_detail';
    let response = add(url,endpoint,data);
      response.then((data)=>{
          console.log(data.status);
          //return data;
          if(data.status){
            Swal.fire({
              icon: 'success',
              title: 'Added!',
              text: `${firstName} ${lastName}'s data has been Added.`,
              showConfirmButton: false,
              timer: 1500,
            });
            setIsAdding(false);
          }else{
            Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: 'Something Went Wrong.',
            showConfirmButton: true,
      });
          }
      });
    
  };

  
  async function add(url,endpoint,data){
        console.log(data);
        console.log('console from function');
       const response =  await fetch( url+endpoint,{
                                    method: "POST", // *GET, POST, PUT, DELETE, etc.
                                    mode: "cors",
                                    headers: {
                                      "Content-Type": "application/json",
                                      //'Content-Type': 'application/x-www-form-urlencoded',
                                    },
                                    body: JSON.stringify(data), // body data type must match "Content-Type" header
                                  }); 
        return response.json();
  }  
 
  return (
    <div className="small-container">

      <Box
        component="form"
       
        sx={{
          '& .MuiTextField-root': { m: 1, width: '50ch' },
          //bgcolor:'#FFFFFF'
        }}
        noValidate
        autoComplete="off"
        onSubmit={handleAdd}
      >
        <h1>Add Employee</h1>
          <TextField
            required
            
            label="First Name"
            onChange={(e)=>{setFirstName(e.target.value)}}
          />

          <TextField
            required
            
            label="Last Name"
            onChange={(e)=>{setLastName(e.target.value)}}
          />

          <TextField
            required
            
            label="Preferred name"
            onChange={(e)=>{setUserName(e.target.value)}}
          />

          <TextField
            required
            type="email"
            label="Email"
            onChange={(e)=>{setEmail(e.target.value)}}
          />
          
          {/* select Field */}

          <FormControl sx={{width: '50ch',m:1}}>
            <InputLabel id="select-four-label">Role</InputLabel>
            <Select
              labelId="select-four-label"
              id="select-four-label"
              value={role}
              label="Status"
              onChange={(e)=>{setRole(e.target.value)}}
              required 
            >
              
            </Select>
          </FormControl>
      
          {/* select Field */}

          <FormControl sx={{width: '50ch',m:1}}>
            <InputLabel id="select-four-label">Status</InputLabel>
            <Select
              labelId="select-four-label"
              id="select-four-label"
              value={status}
              label="Status"
              onChange={(e)=>{setStatus(e.target.value)}}
            >
              <MenuItem value={1}>Active</MenuItem>
              <MenuItem value={0}>Inactive</MenuItem>
            </Select>
          </FormControl>


          <TextField
            required
            
            label="Password"
            type="password"
            onChange={(e)=>{setPassword(e.target.value)}}
          />

          <TextField
            required
            
            label="Confirm Password"
            type="password"
            onChange={(e)=>{setCpassword(e.target.value)}}
          />

           

          
          
          <Box sx={{width: '100ch',m:1}}>
              <Stack direction="row-reverse"
                    spacing={2}>
                <Button variant="outlined" color="error" onClick={() => setIsAdding(false)} type="button">Cancel</Button>
                <Button variant="outlined" type="submit" >Submit</Button>
                
              </Stack>
          </Box>
      </Box>
    </div>
  );
};


export default Add;