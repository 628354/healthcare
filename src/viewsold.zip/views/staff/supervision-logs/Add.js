import React, { useEffect, useState } from 'react'
import Stack from '@mui/material/Stack'
import Button from '@mui/material/Button'
import Box from '@mui/material/Box'
import TextField from '@mui/material/TextField'
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider'
import { DatePicker } from '@mui/x-date-pickers/DatePicker'
import InputLabel from '@mui/material/InputLabel'
import MenuItem from '@mui/material/MenuItem'
import FormControl from '@mui/material/FormControl'
import Select from '@mui/material/Select'
import { Upload } from 'antd'
import { BASE_URL, COMMON_ADD_FUN, COMMON_GET_FUN, COMMON_NEW_ADD, GET_PARTICIPANT_LIST, companyId } from 'helper/ApiInfo'

import dayjs from 'dayjs'

import Swal from 'sweetalert2'

const Add = ({ setIsAdding, setShow }) => {
  const currentDate = new Date()
  const [date, setDate] = useState('')
  const [staff, setStaff] = useState('')
  const [staffList, setStaffList] = useState([])

  const [type, setType] = useState('')
  const [notes, setNotes] = useState('')
  const [nextdueon, setNextDueOn] = useState('')
  const minSelectableDate = dayjs(date).add(1, 'day')

  const [attachment, setAttachment] = useState([])
  // const [cpassword, setCpassword] = useState('');

  // const [role, setRole] = useState('');

  // const [status, setStatus] = useState('');

  useEffect(() => {
    setShow(true)
    return () => setShow(false)
  }, [setShow])

  const handleChange = (e) => {
    const files = e.fileList;
    console.log(files);
    const fileList = [];
    for (let i = 0; i < files.length; i++) {
      fileList.push(files[i].originFileObj); 
    }
    setAttachment(fileList);
  };

  useEffect(() => {
    const staff = localStorage.getItem('user')

    if (staff) {
      const convert = JSON.parse(staff)
      const finalStaff = convert?.stf_id
      setStaff(finalStaff)
    }
  }, [])

  const getStaff = async () => {
    try {
      let response = await COMMON_GET_FUN(GET_PARTICIPANT_LIST.staff)
      if(response.status) {  
        setStaffList(response.messages)
       
      } else {
        throw new Error('Network response was not ok.')
      }
    } catch (error) {
      console.error('Error fetching staff data:', error)
    }
  }

  useEffect(() => {
    getStaff()
  }, [])

  const handleAdd = e => {
    e.preventDefault()

    const emptyFields = [];
    if (!date) {
      emptyFields.push('Date');
    }
    if (!type) {
      emptyFields.push('Type');
    }
    if (!staff) {
      emptyFields.push('Staff');
      
    } if (!nextdueon) {
      emptyFields.push('Next due on');
    }
   
    if (emptyFields.length > 0) {
      return Swal.fire({
        icon: 'error',
        title: 'Error!',
        text: `Please fill in the required fields: ${emptyFields.join(', ')}`,
        showConfirmButton: true,
      });
    }

    //const id = employees.length + 1+1;
    const dateFormat = date ? date.format('YYYY-MM-DD') : null
    const nextdueonDate = nextdueon ? nextdueon.format('YYYY-MM-DD') : null
    const currentTime = dayjs().format('YYYY-MM-DD HH:mm');
    
    const formData = new FormData()
    formData.append('suprvsn_stfid',staff)
    formData.append('suprvsn_date',dateFormat)
    formData.append('suprvsn_type',type)
    formData.append('suprvsn_note',notes)
    formData.append('suprvsn_dueon',nextdueonDate)
    formData.append('company_id', companyId);
    formData.append('created_at', currentTime);
    // Append files
    attachment.forEach((file, index) => {
      formData.append(`image[${index}]`, file);
    });

    let endpoint = 'insertStaffMedia?table=fms_stf_supervision'
    let response = COMMON_ADD_FUN(BASE_URL, endpoint, formData)
    response.then(data => {
     
      if (data.status) {
        Swal.fire({
          icon: 'success',
          title: 'Added!',
          text: `${type} 's data has been Added.`,
          showConfirmButton: false,
          timer: 1500
        })
        setIsAdding(false)
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Error!',
          text: 'Something Went Wrong.',
          showConfirmButton: true
        })
      }
    })
  }


  return (
    <div className='small-container'>
      <Box
        component='form'
        sx={{
          '& .MuiTextField-root': { m: 1, width: '50ch' }
        }}
        noValidate
        autoComplete='off'
        onSubmit={handleAdd}
      >
        <h1>Create Supervision Log</h1>
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <DatePicker
            label='Date'
            format='DD/MM/YYYY'
            minDate={dayjs(currentDate)}
            onChange={newValue => {
              setDate(newValue)
            }}
          />
        </LocalizationProvider>

        <FormControl sx={{ width: '50ch', m: 1 }} required>
          <InputLabel id='Staff'>Staff</InputLabel>
          <Select labelId='Staff' id='Staff' value={staff} label='Staff' onChange={e => setStaff(e.target.value)}>
            {staffList?.map(item => {
              return (
                <MenuItem key={item?.stf_id} value={item?.stf_id}>
                  {item?.stf_firstname} {item?.stf_lastname}
                </MenuItem>
              )
            })}
          </Select>
        </FormControl>

        <TextField
          required
          label='Type'
          onChange={e => {
            setType(e.target.value)
          }}
        />
        <TextField
          required
          label='Notes'
          onChange={e => {
            setNotes(e.target.value)
          }}
        />
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <DatePicker
            label='Next Due On'
            format='DD/MM/YYYY'
            minDate={dayjs(minSelectableDate)}
            onChange={newValue => {
              setNextDueOn(newValue)
            }}
          />
        </LocalizationProvider>

        <Upload
          style={{ width: '100px', display: 'flex', flexDirection: 'row-reverse' }}
          type='file'
          multiple
          listType='picture-card'
          onChange={handleChange}
        >
          <Button size='small'>Click here or Drag and drop a file in this area</Button>
        </Upload>

        <Box sx={{ width: '100ch', m: 1 }}>
          <Stack direction='row-reverse' spacing={2}>
            <Button variant='outlined' color='error' onClick={() => setIsAdding(false)} type='button'>
              Cancel
            </Button>
            <Button variant='outlined' type='submit'>
              Submit
            </Button>
          </Stack>
        </Box>
      </Box>
    </div>
  )
}

export default Add

